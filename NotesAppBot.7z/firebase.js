const firebaseConfig = {
    apiKey: "AIzaSyD6HjHFJLhEDR6pP_Z0F2V707CSppzbTO8",
    authDomain: "testboi-be532.firebaseapp.com",
    projectId: "testboi-be532",
    storageBucket: "testboi-be532.appspot.com",
    messagingSenderId: "388880292538",
    appId: "1:388880292538:web:67f16d02c7d71c4c9a4083",
    measurementId: "G-99Z5XYPR68"
  };
  
  firebase.initializeApp(firebaseConfig);

  const googleSignInButton = document.getElementById('google-sign-in-button');

googleSignInButton.addEventListener('click', () => {
  const provider = new firebase.auth.GoogleAuthProvider();
  firebase.auth().signInWithPopup(provider);
});

firebase.auth().onAuthStateChanged(user => {
    if (user) {
      console.log('User signed in:', user.displayName);
    } else {
      console.log('User signed out');
    }
  });

  const noteForm = document.getElementById('note-form');
const noteInput = document.getElementById('note-input');

noteForm.addEventListener('submit', (e) => {
  e.preventDefault();
  const noteText = noteInput.value;
  const userId = firebase.auth().currentUser.uid;
  const noteRef = firebase.database().ref(`users/${userId}/notes/${Date.now()}`);
  noteRef.set({ text: noteText });
  noteInput.value = '';
});